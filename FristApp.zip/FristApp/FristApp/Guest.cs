﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;
using System.IO;

namespace FristApp
{
    public partial class Guest : Form
    {
        private string s1;
        private string s2;
        private string s3;
        private string s4;

        public static string passingText1;
        public static string passingText2;
        public DataTable DataTable;


        public Guest()
        {
            InitializeComponent();
            fillCombo();

            fillCombo1();
            fillCombo2();
            fillCombo3();
            fillCombo4();
            fillCombo5();

        }
       

        void fillCombo()
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");
            string query = "Select * from Food where Type=@Chinese";
            //con.Open();
            SqlCommand mycommand = new SqlCommand(query, con);
            mycommand.Parameters.AddWithValue("@Chinese","Chinese");
            SqlDataReader Reader;
            try
            {
                con.Open();
                Reader = mycommand.ExecuteReader();

                while (Reader.Read())
                {

                    String sname = (string)Reader["Name"];
                    comboCh.Items.Add(sname);
                }
            }
            catch(Exception r)
            {
                MessageBox.Show("NOT");
            }

        }
        void fillCombo1()
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");
            string query = "Select * from Food where Type=@Thai";
            //con.Open();
            SqlCommand mycommand = new SqlCommand(query, con);
            mycommand.Parameters.AddWithValue("@Thai", "Thai");
            SqlDataReader Reader;
            try
            {
                con.Open();
                Reader = mycommand.ExecuteReader();

                while (Reader.Read())
                {

                    String sname = (string)Reader["Name"];
                    combothai.Items.Add(sname);
                }
            }
            catch (Exception r)
            {
                MessageBox.Show("NOT");
            }

        }
        void fillCombo2()
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");
            string query = "Select * from Food where Type=@Indian";
            //con.Open();
            SqlCommand mycommand = new SqlCommand(query, con);
            mycommand.Parameters.AddWithValue("@Indian", "Indian");
            SqlDataReader Reader;
            try
            {
                con.Open();
                Reader = mycommand.ExecuteReader();

                while (Reader.Read())
                {

                    String sname = (string)Reader["Name"];
                   comboindian.Items.Add(sname);
                }
            }
            catch (Exception r)
            {
                MessageBox.Show("NOT");
            }

        }

        void fillCombo3()
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");
            string query = "Select * from Food where Type=@Desert";
            //con.Open();
            SqlCommand mycommand = new SqlCommand(query, con);
            mycommand.Parameters.AddWithValue("@Desert", "Desert");
            SqlDataReader Reader;
            try
            {
                con.Open();
                Reader = mycommand.ExecuteReader();

                while (Reader.Read())
                {

                    String sname = (string)Reader["Name"];
                    combodeseart.Items.Add(sname);
                }
            }
            catch (Exception r)
            {
                MessageBox.Show("NOT");
            }

        }

        void fillCombo4()
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");
            string query = "Select * from Food where Type=@Bangla";
            //con.Open();
            SqlCommand mycommand = new SqlCommand(query, con);
            mycommand.Parameters.AddWithValue("@Bangla", "Bangla");
            SqlDataReader Reader;
            try
            {
                con.Open();
                Reader = mycommand.ExecuteReader();

                while (Reader.Read())
                {

                    String sname = (string)Reader["Name"];
                    combobangla.Items.Add(sname);
                }
            }
            catch (Exception r)
            {
                MessageBox.Show("NOT");
            }

        }

        void fillCombo5()
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");
            string query = "Select * from Food where Type=@Bevarage ";
            //con.Open();
            SqlCommand mycommand = new SqlCommand(query, con);
            mycommand.Parameters.AddWithValue("@Bevarage ", "Bevarage ");
            SqlDataReader Reader;
            try
            {
                con.Open();
                Reader = mycommand.ExecuteReader();

                while (Reader.Read())
                {

                    String sname = (string)Reader["Name"];
                    comboBeverage.Items.Add(sname);
                }
            }
            catch (Exception r)
            {
                MessageBox.Show("NOT");
            }

        }





        private void Home(object sender, EventArgs e)
        {
            Home f1 = new Home();
            f1.Show();
            this.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void tab_Click(object sender, EventArgs e)
        {
           
        }

        


        private void View2_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");
                //string query = "Select * from Food where Name='"+comboCh.Text+"'";
                //con.Open();
                SqlDataAdapter sdr = new SqlDataAdapter("Select * from Food where Name='" + comboCh.Text + "'", con);
                DataTable dt = new DataTable();
                sdr.Fill(dt);
                textB.Text = dt.Rows[0][2].ToString();
                textP.Text = dt.Rows[0][3].ToString();
                byte[] img = (byte[])dt.Rows[0][4];
                MemoryStream ms = new MemoryStream(img);
                picture.Image = Image.FromStream(ms);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Not");
            }
            
        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void AddClick(object sender, EventArgs e)
        {
            try
            {

                int i = Convert.ToInt32(comboBox2.Text.ToString());
                int j = Convert.ToInt32(textB.Text);

                int total = i * j;
                string s1 = total.ToString();

               // string s1 = textB.Text;
                string s2 = textP.Text;
                string s3 = comboCh.Text;
                string s4 = comboBox2.Text;
                dataGridView1.ColumnCount = 4;
                dataGridView1.Columns[0].Name = "Food Name";
                dataGridView1.Columns[1].Name = "Food Price";
                dataGridView1.Columns[2].Name = "Food Type";
                dataGridView1.Columns[3].Name = "Person";

                string[] row = new string[] { s3,s1,s2,s4};
                dataGridView1.Rows.Add(row);


                MessageBox.Show("done");


            }
            catch(Exception ex)
            {
                MessageBox.Show("not");

            }
            }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int i = Convert.ToInt32(comboperson.Text.ToString());
                int j = Convert.ToInt32(textprice.Text);

                int total = i * j;
                string s1 = total.ToString();

                //string s1 = textprice.Text;
                string s2 = texttype.Text;
                string s3 = combothai.Text;
                string s4 = comboperson.Text;
                dataGridView1.ColumnCount = 4;
                dataGridView1.Columns[0].Name = "Food Name";
                dataGridView1.Columns[1].Name = "Food Price";
                dataGridView1.Columns[2].Name = "Food Type";
                dataGridView1.Columns[3].Name = "Person";

                string[] row = new string[] { s3, s1, s2, s4 };
                dataGridView1.Rows.Add(row);


                MessageBox.Show("done");


            }
            catch (Exception ex)
            {
                MessageBox.Show("not");

            }
        }

        private void view3click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");
                //string query = "Select * from Food where Name='"+comboCh.Text+"'";
                //con.Open();
                SqlDataAdapter sdr = new SqlDataAdapter("Select * from Food where Name='" + combothai.Text + "'", con);
                DataTable dt = new DataTable();
                sdr.Fill(dt);
            textprice.Text = dt.Rows[0][2].ToString();
                texttype.Text = dt.Rows[0][3].ToString();
                byte[] img = (byte[])dt.Rows[0][4];
                MemoryStream ms = new MemoryStream(img);
                picture1.Image = Image.FromStream(ms);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Not");
            }

        }

        private void comboCh_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void combothai_SelectedIndexChanged(object sender, EventArgs e)
        {
           

        }

        private void con_click(object sender, EventArgs e)
        {
            Kitchen o1 = new Kitchen();
            DataGridView sourceGrid = this.dataGridView1;
            DataGridView targetGrid = o1.Kit;
            string s1 = name.Text;
            string s2 = comboTab.Text;
            var targetRows = new List<DataGridViewRow>();
            foreach (DataGridViewRow sourceRow in sourceGrid.Rows)
            {

                if (!sourceRow.IsNewRow)
                {

                    var targetRow = (DataGridViewRow)sourceRow.Clone();

                    foreach (DataGridViewCell cell in sourceRow.Cells)
                    {
                        targetRow.Cells[cell.ColumnIndex].Value = cell.Value;
                    }
                    targetRows.Add(targetRow);

                    targetGrid.Columns.Clear();

                    foreach (DataGridViewColumn column in sourceGrid.Columns)
                    {
                        targetGrid.Columns.Add((DataGridViewColumn)column.Clone());
                    }

                    targetGrid.Rows.AddRange(targetRows.ToArray());


                }
                passingText1 = name.Text;
                passingText2 = comboTab.Text;
                o1.Show();
            }
        }

        private void view4Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");
                //string query = "Select * from Food where Name='"+comboCh.Text+"'";
                //con.Open();
                SqlDataAdapter sdr = new SqlDataAdapter("Select * from Food where Name='" + comboindian.Text + "'", con);
                DataTable dt = new DataTable();
                sdr.Fill(dt);
                textprice2.Text = dt.Rows[0][2].ToString();
                texttype2.Text = dt.Rows[0][3].ToString();
                byte[] img = (byte[])dt.Rows[0][4];
                MemoryStream ms = new MemoryStream(img);
           pictureBox2.Image = Image.FromStream(ms);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Not");
            }
        
        }

        private void AddIndian(object sender, EventArgs e)
        {
            try
            {
                //   SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");

                //    SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Food Where Type='" + comboCh.Text + "'",con);
                //   DataTable dt = new DataTable();
                //  da.Fill(dt);
                // dataGridView1.DataSource = dt;
                int i = Convert.ToInt32(comboperson2.Text.ToString());
                int j = Convert.ToInt32(textprice2.Text);

                int total =i * j;
                string s1= total.ToString();

                //string s1 = textprice2.Text;
                string s2 = texttype2.Text;
                string s3 = comboindian.Text;
                string s4 = comboperson2.Text;
                dataGridView1.ColumnCount = 4;
                dataGridView1.Columns[0].Name = "Food Name";
                dataGridView1.Columns[1].Name = "Food Price";
                dataGridView1.Columns[2].Name = "Food Type";
                dataGridView1.Columns[3].Name = "Person";

                string[] row = new string[] { s3,s1, s2, s4 };
                dataGridView1.Rows.Add(row);


                MessageBox.Show("done");


            }
            catch (Exception ex)
            {
                MessageBox.Show("not");

            }

        }

        private void view5click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");
                //string query = "Select * from Food where Name='"+comboCh.Text+"'";
                //con.Open();
                SqlDataAdapter sdr = new SqlDataAdapter("Select * from Food where Name='" + combodeseart.Text + "'", con);
                DataTable dt = new DataTable();
                sdr.Fill(dt);
                textprice3.Text = dt.Rows[0][2].ToString();
                texttype3.Text = dt.Rows[0][3].ToString();
                byte[] img = (byte[])dt.Rows[0][4];
                MemoryStream ms = new MemoryStream(img);
                pictureBox1.Image = Image.FromStream(ms);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Not");
            }

        }

        private void AddDeseart(object sender, EventArgs e)
        {
            try
            {
                //   SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");

                //    SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Food Where Type='" + comboCh.Text + "'",con);
                //   DataTable dt = new DataTable();
                //  da.Fill(dt);
                // dataGridView1.DataSource = dt;
                int i = Convert.ToInt32(comboperson3.Text.ToString());
                int j = Convert.ToInt32(textprice3.Text);

                int total = i * j;
                string s1 = total.ToString();

             //   string s1 = textprice3.Text;
                string s2 = texttype3.Text;
                string s3 = combodeseart.Text;
                string s4 = comboperson3.Text;
                dataGridView1.ColumnCount = 4;
                dataGridView1.Columns[0].Name = "Food Name";
                dataGridView1.Columns[1].Name = "Food Price";
                dataGridView1.Columns[2].Name = "Food Type";
                dataGridView1.Columns[3].Name = "Person";

                string[] row = new string[] { s3, s1, s2, s4 };
                dataGridView1.Rows.Add(row);


                MessageBox.Show("done");


            }
            catch (Exception ex)
            {
                MessageBox.Show("not");

            }
        }

        private void view6click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");
                //string query = "Select * from Food where Name='"+comboCh.Text+"'";
                //con.Open();
                SqlDataAdapter sdr = new SqlDataAdapter("Select * from Food where Name='" + combobangla.Text + "'", con);
                DataTable dt = new DataTable();
                sdr.Fill(dt);
                textprice4.Text = dt.Rows[0][2].ToString();
                texttype4.Text = dt.Rows[0][3].ToString();
                byte[] img = (byte[])dt.Rows[0][4];
                MemoryStream ms = new MemoryStream(img);
                pictureBox5.Image = Image.FromStream(ms);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Not");
            }
        }

        private void AddBangla(object sender, EventArgs e)
        {

            try
            {
                //   SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");

                //    SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Food Where Type='" + comboCh.Text + "'",con);
                //   DataTable dt = new DataTable();
                //  da.Fill(dt);
                // dataGridView1.DataSource = dt;

                int i = Convert.ToInt32(comboperson4.Text.ToString());
                int j = Convert.ToInt32(textprice4.Text);

                int total = i * j;
                string s1 = total.ToString();

               // string s1 = textprice4.Text;
                string s2 = texttype4.Text;
                string s3 = combobangla.Text;
                string s4 = comboperson4.Text;
                dataGridView1.ColumnCount = 4;
                dataGridView1.Columns[0].Name = "Food Name";
                dataGridView1.Columns[1].Name = "Food Price";
                dataGridView1.Columns[2].Name = "Food Type";
                dataGridView1.Columns[3].Name = "Person";

                string[] row = new string[] { s3, s1, s2, s4 };
                dataGridView1.Rows.Add(row);


                MessageBox.Show("done");


            }
            catch (Exception ex)
            {
                MessageBox.Show("not");

            }

        }

        private void ViewbtnBeverage_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");
                //string query = "Select * from Food where Name='"+comboCh.Text+"'";
                //con.Open();
                SqlDataAdapter sdr = new SqlDataAdapter("Select * from Food where Name='" + comboBeverage.Text + "'", con);
                DataTable dt = new DataTable();
                sdr.Fill(dt);
                pricetextBoxBeverage.Text = dt.Rows[0][2].ToString();
                TypetextBoxBeverage.Text = dt.Rows[0][3].ToString();
                byte[] img = (byte[])dt.Rows[0][4];
                MemoryStream ms = new MemoryStream(img);
                pictureBoxBeverage.Image = Image.FromStream(ms);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Not");
            }
        }

        private void AddbuttonBeverage_Click(object sender, EventArgs e)
        {
            try
            {
                //   SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");

                //    SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Food Where Type='" + comboCh.Text + "'",con);
                //   DataTable dt = new DataTable();
                //  da.Fill(dt);
                // dataGridView1.DataSource = dt;

                int i = Convert.ToInt32(comboBoxBeverage.Text.ToString());
                int j = Convert.ToInt32(pricetextBoxBeverage.Text);

                int total = i * j;
                string s1 = total.ToString();

             //   string s1 = pricetextBoxBeverage.Text;
                string s2 = TypetextBoxBeverage.Text;
                
                string s3 =comboBeverage.Text;
                string s4 = comboBoxBeverage.Text;
                dataGridView1.ColumnCount = 4;
                dataGridView1.Columns[0].Name = "Food Name";
                dataGridView1.Columns[1].Name = "Food Price";
                dataGridView1.Columns[2].Name = "Food Type";
                dataGridView1.Columns[3].Name = "Person";

                string[] row = new string[] { s3, s1, s2, s4 };
                dataGridView1.Rows.Add(row);


                MessageBox.Show("done");


            }
            catch (Exception ex)
            {
                MessageBox.Show("not");

            }
        }

        private void Del_Ite(object sender, EventArgs e)
        {
            int RowIndex = dataGridView1.CurrentCell.RowIndex;
            dataGridView1.Rows.RemoveAt(RowIndex);
        }
    }
}
