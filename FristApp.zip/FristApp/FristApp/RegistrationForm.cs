﻿using System.Drawing;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RestaurentRepository;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Net;

namespace FristApp
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void Confirm_Hover(object sender, EventArgs e)
        {
            confirm.BackColor = Color.Blue;
           confirm.ForeColor = Color.White;
        }

        private void Confirm_leave(object sender, EventArgs e)
        {
            confirm.BackColor = Color.Gray;
            confirm.ForeColor = Color.Green;
        }

        private void click_Back(object sender, EventArgs e)
        {
            ManagmentLogin m1 = new ManagmentLogin();
            m1.Show();
            this.Close();
        }

        private void Back_Hover(object sender, EventArgs e)
        {
            Back.BackColor = Color.Gray;
            Back.ForeColor = Color.Maroon;
        }

        private void Back_Leave(object sender, EventArgs e)
        {
          Back.BackColor = Color.DarkOliveGreen;
          Back.ForeColor = Color.Peru;
        }

        private void Confirm_Click(object sender, EventArgs e)
        {
            int s1 = Convert.ToInt32(this.textBox1.Text);
            string s2 = this.textBox2.Text;
            int s3 = Convert.ToInt32(this.textBox3.Text);
            string s4 = this.textBox4.Text;
            string s5 = this.textBox5.Text;
            string s6 = textBox6.Text;
            try
            {
                string query = "INSERT into Reg (Id,Name,Age,Email,Mobile,Password) VALUES ('" + s1 + "', '" + s2 + "', '" + s3 + "', '" + s4 + "', '" + s5 + "', " + s6 + ")";
                CoonectionClass dcc = new CoonectionClass();
                dcc.ConnectWithDB();
                int x = dcc.ExecuteSQL(query);
                MessageBox.Show("Registered");
                dcc.CloseConnection();

            }
            catch (WebException ex) 
            {
                MessageBox.Show("Error while tried to do something. Error: " + ex.Message);
            }
            catch (Exception ex) // <- this 'ex' is null
            {
                MessageBox.Show("Error while tried to do something. Error: " + ex.Message);
            }

        }
    }

    
}
