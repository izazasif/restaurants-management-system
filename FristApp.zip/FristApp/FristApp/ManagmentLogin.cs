﻿using System;
using RestaurentRepository;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;


namespace FristApp
{
    public partial class ManagmentLogin : Form
    {
        public ManagmentLogin()
        {
            InitializeComponent();
        }

        private void ManagmentLogin_Load(object sender, EventArgs e)
        {

        }

        private void Registration_click(object sender, EventArgs e)
        {
            RegistrationForm r1 = new RegistrationForm();
            r1.Show();
            this.Close();     
        }

        private void Login_Click(object sender, EventArgs e)
        {
            try
            {
                /*  string query = "SELECT count(*) from Reg WHERE Name='" + textBox1.Text + "' and Password='" + textBox2.Text + "' ";
                  CoonectionClass dcc = new CoonectionClass();
                  dcc.ConnectWithDB();
                  DataTable dt = new DataTable();
                  //  int temp = Convert.ToInt32(dcc.ExecuteSQL(query).ToString());
                  SqlDataReader sdr = dcc.GetData(query);
                  dcc.CloseConnection();
                  */
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");
                SqlDataAdapter sdr = new SqlDataAdapter("SELECT count(*) from Reg WHERE Name = '" + textBox1.Text + "' and Password = '" + textBox2.Text + "' ", con);
                DataTable dt = new DataTable();
                sdr.Fill(dt);
                if (dt.Rows[0][0].ToString() == "1")
                    {
                    AddEmployee em = new AddEmployee();
                    em.Show();
                    this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Not");
                    }          
            }
            catch(Exception r)
            {
                MessageBox.Show("Exception");
            }

        }
    }
}
