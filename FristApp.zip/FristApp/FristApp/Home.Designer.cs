﻿namespace FristApp
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.Enter = new System.Windows.Forms.Button();
            this.radio1 = new System.Windows.Forms.RadioButton();
            this.radio2 = new System.Windows.Forms.RadioButton();
            this.radio3 = new System.Windows.Forms.RadioButton();
            this.Rightpanel = new System.Windows.Forms.Panel();
            this.Uppanel = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Rightpanel.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Enter
            // 
            this.Enter.AccessibleRole = System.Windows.Forms.AccessibleRole.Alert;
            this.Enter.BackColor = System.Drawing.SystemColors.Info;
            this.Enter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Enter.Font = new System.Drawing.Font("Modern No. 20", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Enter.ForeColor = System.Drawing.Color.Black;
            this.Enter.Location = new System.Drawing.Point(30, 275);
            this.Enter.Margin = new System.Windows.Forms.Padding(4);
            this.Enter.Name = "Enter";
            this.Enter.Size = new System.Drawing.Size(127, 46);
            this.Enter.TabIndex = 0;
            this.Enter.Text = "Enter";
            this.Enter.UseVisualStyleBackColor = false;
            this.Enter.Click += new System.EventHandler(this.FormC);
            this.Enter.MouseLeave += new System.EventHandler(this.LoginBtnLeft);
            this.Enter.MouseHover += new System.EventHandler(this.LoginButtonHovered);
            // 
            // radio1
            // 
            this.radio1.AutoSize = true;
            this.radio1.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.radio1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.radio1.Font = new System.Drawing.Font("Wide Latin", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radio1.ForeColor = System.Drawing.Color.Transparent;
            this.radio1.Location = new System.Drawing.Point(8, 120);
            this.radio1.Name = "radio1";
            this.radio1.Size = new System.Drawing.Size(161, 34);
            this.radio1.TabIndex = 2;
            this.radio1.TabStop = true;
            this.radio1.Text = "Guest";
            this.radio1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.radio1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.radio1.UseVisualStyleBackColor = true;
            this.radio1.UseWaitCursor = true;
            // 
            // radio2
            // 
            this.radio2.AutoSize = true;
            this.radio2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.radio2.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.radio2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.radio2.Font = new System.Drawing.Font("Wide Latin", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radio2.Location = new System.Drawing.Point(8, 169);
            this.radio2.Name = "radio2";
            this.radio2.Size = new System.Drawing.Size(248, 34);
            this.radio2.TabIndex = 2;
            this.radio2.TabStop = true;
            this.radio2.Text = "Employee";
            this.radio2.UseVisualStyleBackColor = true;
            // 
            // radio3
            // 
            this.radio3.AutoSize = true;
            this.radio3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.radio3.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.radio3.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.radio3.Font = new System.Drawing.Font("Wide Latin", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radio3.Location = new System.Drawing.Point(8, 218);
            this.radio3.Name = "radio3";
            this.radio3.Size = new System.Drawing.Size(222, 34);
            this.radio3.TabIndex = 2;
            this.radio3.TabStop = true;
            this.radio3.Text = "Manager";
            this.radio3.UseVisualStyleBackColor = false;
            // 
            // Rightpanel
            // 
            this.Rightpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Rightpanel.Controls.Add(this.radio2);
            this.Rightpanel.Controls.Add(this.Enter);
            this.Rightpanel.Controls.Add(this.radio3);
            this.Rightpanel.Controls.Add(this.radio1);
            this.Rightpanel.Location = new System.Drawing.Point(720, -1);
            this.Rightpanel.Name = "Rightpanel";
            this.Rightpanel.Size = new System.Drawing.Size(260, 560);
            this.Rightpanel.TabIndex = 3;
            // 
            // Uppanel
            // 
            this.Uppanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Uppanel.Location = new System.Drawing.Point(0, -1);
            this.Uppanel.Name = "Uppanel";
            this.Uppanel.Size = new System.Drawing.Size(980, 103);
            this.Uppanel.TabIndex = 4;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(0, 99);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(137, 460);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::FristApp.Properties.Resources._160295_The_Studio_Foto_The_Standard;
            this.pictureBox2.Location = new System.Drawing.Point(134, 102);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(588, 457);
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::FristApp.Properties.Resources._3_restaurant_logo_design;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(137, 113);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(980, 557);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Uppanel);
            this.Controls.Add(this.Rightpanel);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Home";
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "My";
            this.Rightpanel.ResumeLayout(false);
            this.Rightpanel.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private new System.Windows.Forms.Button Enter;
        private System.Windows.Forms.RadioButton radio2;
        private System.Windows.Forms.RadioButton radio3;
        private System.Windows.Forms.RadioButton radio1;
        private System.Windows.Forms.Panel Rightpanel;
        private System.Windows.Forms.Panel Uppanel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

