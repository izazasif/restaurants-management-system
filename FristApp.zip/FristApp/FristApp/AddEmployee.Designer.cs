﻿namespace FristApp
{
    partial class AddEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddEmployee));
            this.Leftpanel = new System.Windows.Forms.Panel();
            this.ExitBttn = new System.Windows.Forms.Button();
            this.BillBttn = new System.Windows.Forms.Button();
            this.SearchBttn = new System.Windows.Forms.Button();
            this.AddFoodbutton = new System.Windows.Forms.Button();
            this.UpdateEmpBttn = new System.Windows.Forms.Button();
            this.AddEmpBttn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.UpdateEmployeepanel = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.UPEPositioncomboBox = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.Updatebutton = new System.Windows.Forms.Button();
            this.UPEPhonenumbertextBox = new System.Windows.Forms.TextBox();
            this.UPEPasswordtextBox = new System.Windows.Forms.TextBox();
            this.UPENametextBox = new System.Windows.Forms.TextBox();
            this.UPEUsernametextBox = new System.Windows.Forms.TextBox();
            this.UPEIdtextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.EIdtextBox = new System.Windows.Forms.TextBox();
            this.EUsernametextBox = new System.Windows.Forms.TextBox();
            this.ENametextBox = new System.Windows.Forms.TextBox();
            this.EPasswordtextBox = new System.Windows.Forms.TextBox();
            this.EPhoneNumbertextBox = new System.Windows.Forms.TextBox();
            this.Insurtbutton = new System.Windows.Forms.Button();
            this.AddEmployeepanel = new System.Windows.Forms.Panel();
            this.EPositioncomboBox = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.Leftpanel.SuspendLayout();
            this.UpdateEmployeepanel.SuspendLayout();
            this.AddEmployeepanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Leftpanel
            // 
            this.Leftpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Leftpanel.Controls.Add(this.ExitBttn);
            this.Leftpanel.Controls.Add(this.BillBttn);
            this.Leftpanel.Controls.Add(this.SearchBttn);
            this.Leftpanel.Controls.Add(this.AddFoodbutton);
            this.Leftpanel.Controls.Add(this.UpdateEmpBttn);
            this.Leftpanel.Controls.Add(this.AddEmpBttn);
            this.Leftpanel.Location = new System.Drawing.Point(0, 0);
            this.Leftpanel.Name = "Leftpanel";
            this.Leftpanel.Size = new System.Drawing.Size(124, 557);
            this.Leftpanel.TabIndex = 0;
            // 
            // ExitBttn
            // 
            this.ExitBttn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ExitBttn.Location = new System.Drawing.Point(3, 368);
            this.ExitBttn.Name = "ExitBttn";
            this.ExitBttn.Size = new System.Drawing.Size(118, 46);
            this.ExitBttn.TabIndex = 7;
            this.ExitBttn.Text = "Logout";
            this.ExitBttn.UseVisualStyleBackColor = true;
            this.ExitBttn.Click += new System.EventHandler(this.ExitBttn_Click);
            // 
            // BillBttn
            // 
            this.BillBttn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BillBttn.Location = new System.Drawing.Point(3, 315);
            this.BillBttn.Name = "BillBttn";
            this.BillBttn.Size = new System.Drawing.Size(118, 46);
            this.BillBttn.TabIndex = 6;
            this.BillBttn.Text = "Bill";
            this.BillBttn.UseVisualStyleBackColor = true;
            this.BillBttn.Click += new System.EventHandler(this.Bill_Click);
            // 
            // SearchBttn
            // 
            this.SearchBttn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SearchBttn.Location = new System.Drawing.Point(3, 263);
            this.SearchBttn.Name = "SearchBttn";
            this.SearchBttn.Size = new System.Drawing.Size(118, 46);
            this.SearchBttn.TabIndex = 5;
            this.SearchBttn.Text = "Search";
            this.SearchBttn.UseVisualStyleBackColor = true;
            this.SearchBttn.Click += new System.EventHandler(this.SearchBttn_Click);
            // 
            // AddFoodbutton
            // 
            this.AddFoodbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddFoodbutton.Location = new System.Drawing.Point(3, 211);
            this.AddFoodbutton.Name = "AddFoodbutton";
            this.AddFoodbutton.Size = new System.Drawing.Size(118, 46);
            this.AddFoodbutton.TabIndex = 4;
            this.AddFoodbutton.Text = "Add Food";
            this.AddFoodbutton.UseVisualStyleBackColor = true;
            this.AddFoodbutton.Click += new System.EventHandler(this.AddFoodbutton_Click);
            // 
            // UpdateEmpBttn
            // 
            this.UpdateEmpBttn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UpdateEmpBttn.Location = new System.Drawing.Point(3, 158);
            this.UpdateEmpBttn.Name = "UpdateEmpBttn";
            this.UpdateEmpBttn.Size = new System.Drawing.Size(118, 46);
            this.UpdateEmpBttn.TabIndex = 3;
            this.UpdateEmpBttn.Text = "Update Employee";
            this.UpdateEmpBttn.UseVisualStyleBackColor = true;
            this.UpdateEmpBttn.Click += new System.EventHandler(this.UpdateEmpBttn_Click);
            // 
            // AddEmpBttn
            // 
            this.AddEmpBttn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddEmpBttn.Location = new System.Drawing.Point(3, 106);
            this.AddEmpBttn.Name = "AddEmpBttn";
            this.AddEmpBttn.Size = new System.Drawing.Size(118, 46);
            this.AddEmpBttn.TabIndex = 2;
            this.AddEmpBttn.Text = "Add Employee";
            this.AddEmpBttn.UseVisualStyleBackColor = true;
            this.AddEmpBttn.Click += new System.EventHandler(this.AddEmpBttn_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(986, 100);
            this.panel1.TabIndex = 1;
            // 
            // UpdateEmployeepanel
            // 
            this.UpdateEmployeepanel.Controls.Add(this.label15);
            this.UpdateEmployeepanel.Controls.Add(this.UPEPositioncomboBox);
            this.UpdateEmployeepanel.Controls.Add(this.label14);
            this.UpdateEmployeepanel.Controls.Add(this.Updatebutton);
            this.UpdateEmployeepanel.Controls.Add(this.UPEPhonenumbertextBox);
            this.UpdateEmployeepanel.Controls.Add(this.UPEPasswordtextBox);
            this.UpdateEmployeepanel.Controls.Add(this.UPENametextBox);
            this.UpdateEmployeepanel.Controls.Add(this.UPEUsernametextBox);
            this.UpdateEmployeepanel.Controls.Add(this.UPEIdtextBox);
            this.UpdateEmployeepanel.Controls.Add(this.label7);
            this.UpdateEmployeepanel.Controls.Add(this.label8);
            this.UpdateEmployeepanel.Controls.Add(this.label9);
            this.UpdateEmployeepanel.Controls.Add(this.label10);
            this.UpdateEmployeepanel.Controls.Add(this.label11);
            this.UpdateEmployeepanel.Controls.Add(this.label12);
            this.UpdateEmployeepanel.Location = new System.Drawing.Point(130, 129);
            this.UpdateEmployeepanel.Name = "UpdateEmployeepanel";
            this.UpdateEmployeepanel.Size = new System.Drawing.Size(833, 428);
            this.UpdateEmployeepanel.TabIndex = 11;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(353, 120);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(199, 20);
            this.label15.TabIndex = 17;
            this.label15.Text = "By Employee Username";
            // 
            // UPEPositioncomboBox
            // 
            this.UPEPositioncomboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UPEPositioncomboBox.FormattingEnabled = true;
            this.UPEPositioncomboBox.Items.AddRange(new object[] {
            "Employee",
            "Cheaf",
            "Waiter",
            "Others",
            ""});
            this.UPEPositioncomboBox.Location = new System.Drawing.Point(307, 370);
            this.UPEPositioncomboBox.Name = "UPEPositioncomboBox";
            this.UPEPositioncomboBox.Size = new System.Drawing.Size(157, 28);
            this.UPEPositioncomboBox.TabIndex = 16;
            this.UPEPositioncomboBox.Text = "Select One";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(125, 373);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(156, 20);
            this.label14.TabIndex = 15;
            this.label14.Text = "Employee Position";
            // 
            // Updatebutton
            // 
            this.Updatebutton.Font = new System.Drawing.Font("Sitka Small", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Updatebutton.Location = new System.Drawing.Point(619, 207);
            this.Updatebutton.Name = "Updatebutton";
            this.Updatebutton.Size = new System.Drawing.Size(171, 59);
            this.Updatebutton.TabIndex = 13;
            this.Updatebutton.Text = "Update";
            this.Updatebutton.UseVisualStyleBackColor = true;
            this.Updatebutton.Click += new System.EventHandler(this.Updatebutton_Click);
            // 
            // UPEPhonenumbertextBox
            // 
            this.UPEPhonenumbertextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UPEPhonenumbertextBox.Location = new System.Drawing.Point(307, 330);
            this.UPEPhonenumbertextBox.Name = "UPEPhonenumbertextBox";
            this.UPEPhonenumbertextBox.Size = new System.Drawing.Size(157, 26);
            this.UPEPhonenumbertextBox.TabIndex = 10;
            // 
            // UPEPasswordtextBox
            // 
            this.UPEPasswordtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UPEPasswordtextBox.Location = new System.Drawing.Point(307, 289);
            this.UPEPasswordtextBox.Name = "UPEPasswordtextBox";
            this.UPEPasswordtextBox.Size = new System.Drawing.Size(157, 26);
            this.UPEPasswordtextBox.TabIndex = 9;
            // 
            // UPENametextBox
            // 
            this.UPENametextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UPENametextBox.Location = new System.Drawing.Point(307, 247);
            this.UPENametextBox.Name = "UPENametextBox";
            this.UPENametextBox.Size = new System.Drawing.Size(157, 26);
            this.UPENametextBox.TabIndex = 8;
            // 
            // UPEUsernametextBox
            // 
            this.UPEUsernametextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UPEUsernametextBox.Location = new System.Drawing.Point(307, 207);
            this.UPEUsernametextBox.Name = "UPEUsernametextBox";
            this.UPEUsernametextBox.Size = new System.Drawing.Size(157, 26);
            this.UPEUsernametextBox.TabIndex = 7;
            // 
            // UPEIdtextBox
            // 
            this.UPEIdtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UPEIdtextBox.Location = new System.Drawing.Point(307, 167);
            this.UPEIdtextBox.Name = "UPEIdtextBox";
            this.UPEIdtextBox.Size = new System.Drawing.Size(157, 26);
            this.UPEIdtextBox.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(344, 90);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(212, 20);
            this.label7.TabIndex = 5;
            this.label7.Text = "Update Employee Details";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(71, 336);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(210, 20);
            this.label8.TabIndex = 4;
            this.label8.Text = "Employee Phone Number";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(112, 289);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(169, 20);
            this.label9.TabIndex = 3;
            this.label9.Text = "Employee Password";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(143, 247);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(138, 20);
            this.label10.TabIndex = 2;
            this.label10.Text = "Employee Name";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(107, 207);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(174, 20);
            this.label11.TabIndex = 1;
            this.label11.Text = "Employee Username";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(173, 167);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(108, 20);
            this.label12.TabIndex = 0;
            this.label12.Text = "Employee Id";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(173, 167);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Employee Id";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(107, 207);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(174, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Employee Username";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(143, 247);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Employee Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(112, 289);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(169, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Employee Password";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(71, 336);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(210, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Employee Phone Number";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(344, 90);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(224, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Add New Employee Details";
            // 
            // EIdtextBox
            // 
            this.EIdtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EIdtextBox.Location = new System.Drawing.Point(307, 167);
            this.EIdtextBox.Name = "EIdtextBox";
            this.EIdtextBox.Size = new System.Drawing.Size(157, 26);
            this.EIdtextBox.TabIndex = 6;
            // 
            // EUsernametextBox
            // 
            this.EUsernametextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EUsernametextBox.Location = new System.Drawing.Point(307, 207);
            this.EUsernametextBox.Name = "EUsernametextBox";
            this.EUsernametextBox.Size = new System.Drawing.Size(157, 26);
            this.EUsernametextBox.TabIndex = 7;
            // 
            // ENametextBox
            // 
            this.ENametextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ENametextBox.Location = new System.Drawing.Point(307, 247);
            this.ENametextBox.Name = "ENametextBox";
            this.ENametextBox.Size = new System.Drawing.Size(157, 26);
            this.ENametextBox.TabIndex = 8;
            // 
            // EPasswordtextBox
            // 
            this.EPasswordtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EPasswordtextBox.Location = new System.Drawing.Point(307, 289);
            this.EPasswordtextBox.Name = "EPasswordtextBox";
            this.EPasswordtextBox.Size = new System.Drawing.Size(157, 26);
            this.EPasswordtextBox.TabIndex = 9;
            // 
            // EPhoneNumbertextBox
            // 
            this.EPhoneNumbertextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EPhoneNumbertextBox.Location = new System.Drawing.Point(307, 330);
            this.EPhoneNumbertextBox.Name = "EPhoneNumbertextBox";
            this.EPhoneNumbertextBox.Size = new System.Drawing.Size(157, 26);
            this.EPhoneNumbertextBox.TabIndex = 10;
            // 
            // Insurtbutton
            // 
            this.Insurtbutton.Font = new System.Drawing.Font("Sitka Small", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Insurtbutton.Location = new System.Drawing.Point(651, 80);
            this.Insurtbutton.Name = "Insurtbutton";
            this.Insurtbutton.Size = new System.Drawing.Size(139, 59);
            this.Insurtbutton.TabIndex = 12;
            this.Insurtbutton.Text = "Add";
            this.Insurtbutton.UseVisualStyleBackColor = true;
            this.Insurtbutton.Click += new System.EventHandler(this.Insertbutton_Click);
            // 
            // AddEmployeepanel
            // 
            this.AddEmployeepanel.Controls.Add(this.EPositioncomboBox);
            this.AddEmployeepanel.Controls.Add(this.label13);
            this.AddEmployeepanel.Controls.Add(this.Insurtbutton);
            this.AddEmployeepanel.Controls.Add(this.EPhoneNumbertextBox);
            this.AddEmployeepanel.Controls.Add(this.EPasswordtextBox);
            this.AddEmployeepanel.Controls.Add(this.ENametextBox);
            this.AddEmployeepanel.Controls.Add(this.EUsernametextBox);
            this.AddEmployeepanel.Controls.Add(this.EIdtextBox);
            this.AddEmployeepanel.Controls.Add(this.label6);
            this.AddEmployeepanel.Controls.Add(this.label5);
            this.AddEmployeepanel.Controls.Add(this.label4);
            this.AddEmployeepanel.Controls.Add(this.label3);
            this.AddEmployeepanel.Controls.Add(this.label2);
            this.AddEmployeepanel.Controls.Add(this.label1);
            this.AddEmployeepanel.Location = new System.Drawing.Point(139, 121);
            this.AddEmployeepanel.Name = "AddEmployeepanel";
            this.AddEmployeepanel.Size = new System.Drawing.Size(833, 428);
            this.AddEmployeepanel.TabIndex = 2;
            // 
            // EPositioncomboBox
            // 
            this.EPositioncomboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EPositioncomboBox.FormattingEnabled = true;
            this.EPositioncomboBox.Items.AddRange(new object[] {
            "Employee",
            "Cheaf",
            "Waiter",
            "Others",
            ""});
            this.EPositioncomboBox.Location = new System.Drawing.Point(307, 375);
            this.EPositioncomboBox.Name = "EPositioncomboBox";
            this.EPositioncomboBox.Size = new System.Drawing.Size(157, 28);
            this.EPositioncomboBox.TabIndex = 14;
            this.EPositioncomboBox.Text = "Select One";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(125, 378);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(156, 20);
            this.label13.TabIndex = 13;
            this.label13.Text = "Employee Position";
            // 
            // AddEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.Controls.Add(this.UpdateEmployeepanel);
            this.Controls.Add(this.AddEmployeepanel);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Leftpanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AddEmployee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddEmployee";
            this.Leftpanel.ResumeLayout(false);
            this.UpdateEmployeepanel.ResumeLayout(false);
            this.UpdateEmployeepanel.PerformLayout();
            this.AddEmployeepanel.ResumeLayout(false);
            this.AddEmployeepanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Leftpanel;
        private System.Windows.Forms.Button UpdateEmpBttn;
        private System.Windows.Forms.Button AddEmpBttn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button AddFoodbutton;
        private System.Windows.Forms.Panel UpdateEmployeepanel;
        private System.Windows.Forms.Button Updatebutton;
        private System.Windows.Forms.TextBox UPEPhonenumbertextBox;
        private System.Windows.Forms.TextBox UPEPasswordtextBox;
        private System.Windows.Forms.TextBox UPENametextBox;
        private System.Windows.Forms.TextBox UPEUsernametextBox;
        private System.Windows.Forms.TextBox UPEIdtextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel AddEmployeepanel;
        private System.Windows.Forms.Button Insurtbutton;
        private System.Windows.Forms.TextBox EPhoneNumbertextBox;
        private System.Windows.Forms.TextBox EPasswordtextBox;
        private System.Windows.Forms.TextBox ENametextBox;
        private System.Windows.Forms.TextBox EUsernametextBox;
        private System.Windows.Forms.TextBox EIdtextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ExitBttn;
        private System.Windows.Forms.Button BillBttn;
        private System.Windows.Forms.Button SearchBttn;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox EPositioncomboBox;
        private System.Windows.Forms.ComboBox UPEPositioncomboBox;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
    }
}