﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace FristApp
{
    public partial class KitchenLogin : Form
    {
        public KitchenLogin()
        {
            InitializeComponent();
        }

        private void Loginbutton_Click(object sender, EventArgs e)
        {
            try
            {
                
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");
                SqlDataAdapter sdr = new SqlDataAdapter("SELECT count(*) from Employeinfo WHERE eusername = '" + UsernametextBox.Text + "' and epassword = '" + PasswordtextBox.Text + "'", con);
                DataTable dt = new DataTable();
                sdr.Fill(dt);
                if (dt.Rows[0][0].ToString() == "1")
                {
                    Kitchen k = new Kitchen();
                    k.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Not");
                }
            }
            catch (Exception r)
            {
                MessageBox.Show("Exception");
            }
        }
    }
}
