﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FristApp
{
    public partial class EmployeeSearch : Form
    {
        public EmployeeSearch()
        {
            InitializeComponent();
        }

        private void Backbutton_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddEmployee es = new AddEmployee();
            es.ShowDialog();
            this.Close();
        }

        private void search(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");
            string query = "Select * from Employeinfo WHERE Id=" + int.Parse(SearchtextBox.Text);

            con.Open();
            SqlCommand mycommand = new SqlCommand(query, con);
            SqlDataReader s = mycommand.ExecuteReader();
            if (s.Read())
            {
                
                  
                    
                    string s1=(s["Id"].ToString());
                    string s2 = (s["ename"].ToString());
                    string s3 = (s["eusername"].ToString());
                    string s4 = (s["epassword"].ToString());
                    string s5 = (s["emobilenumber"].ToString());
                    string s6 = (s["eposition"].ToString());
                    dataGridView1.ColumnCount = 6;
                    dataGridView1.Columns[0].Name = "ID";
                    dataGridView1.Columns[1].Name = "Name";
                    dataGridView1.Columns[2].Name = "User Name";
                    dataGridView1.Columns[3].Name = "Password";
                    dataGridView1.Columns[4].Name = "Mobilenumber";
                    dataGridView1.Columns[5].Name = "Position";

                    string[] row = new string[] { s1, s2, s3, s4,s5,s6 };
                    dataGridView1.Rows.Add(row);


                    MessageBox.Show("done");

            }



            con.Close();
        }

        private void delete_emp(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");
            string query = "Delete from Employeinfo WHERE Id='"+this.SearchtextBox.Text+"';";

            con.Open();
            SqlCommand mycommand = new SqlCommand(query, con);
            SqlDataReader s = mycommand.ExecuteReader();
            MessageBox.Show("delete");
            if (s.Read())
            {
                SearchtextBox.Clear();
            }
            con.Close();

        }
    }
}
