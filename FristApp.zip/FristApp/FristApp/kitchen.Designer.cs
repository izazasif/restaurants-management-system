﻿namespace FristApp
{
    partial class Kitchen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Kitchen));
            this.OrdermassageLbl = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textSum = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Kit = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label14 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboW = new System.Windows.Forms.ComboBox();
            this.Bill = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Kit)).BeginInit();
            this.SuspendLayout();
            // 
            // OrdermassageLbl
            // 
            this.OrdermassageLbl.AutoSize = true;
            this.OrdermassageLbl.BackColor = System.Drawing.Color.Silver;
            this.OrdermassageLbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OrdermassageLbl.Font = new System.Drawing.Font("Mistral", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrdermassageLbl.Location = new System.Drawing.Point(191, 22);
            this.OrdermassageLbl.Name = "OrdermassageLbl";
            this.OrdermassageLbl.Size = new System.Drawing.Size(193, 57);
            this.OrdermassageLbl.TabIndex = 1;
            this.OrdermassageLbl.Text = "Order List";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(65, 56);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(502, 59);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 4;
            // 
            // textSum
            // 
            this.textSum.Location = new System.Drawing.Point(564, 234);
            this.textSum.Name = "textSum";
            this.textSum.Size = new System.Drawing.Size(100, 20);
            this.textSum.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.button1.Location = new System.Drawing.Point(564, 286);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(143, 33);
            this.button1.TabIndex = 6;
            this.button1.Text = "Total";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Kit
            // 
            this.Kit.BackgroundColor = System.Drawing.Color.Silver;
            this.Kit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Kit.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.Kit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Kit.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4});
            this.Kit.Location = new System.Drawing.Point(12, 85);
            this.Kit.Name = "Kit";
            this.Kit.Size = new System.Drawing.Size(546, 424);
            this.Kit.TabIndex = 7;
            this.Kit.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Kit_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Column1";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Column2";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Column3";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Column4";
            this.Column4.Name = "Column4";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Maroon;
            this.label14.Location = new System.Drawing.Point(9, 57);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(49, 16);
            this.label14.TabIndex = 9;
            this.label14.Text = "Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(409, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 16);
            this.label1.TabIndex = 10;
            this.label1.Text = "Table No";
            // 
            // comboW
            // 
            this.comboW.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboW.FormattingEnabled = true;
            this.comboW.Location = new System.Drawing.Point(564, 177);
            this.comboW.Name = "comboW";
            this.comboW.Size = new System.Drawing.Size(165, 32);
            this.comboW.TabIndex = 11;
            this.comboW.Text = "Select Waiter";
            // 
            // Bill
            // 
            this.Bill.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Bill.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bill.ForeColor = System.Drawing.Color.Maroon;
            this.Bill.Location = new System.Drawing.Point(583, 415);
            this.Bill.Name = "Bill";
            this.Bill.Size = new System.Drawing.Size(165, 44);
            this.Bill.TabIndex = 12;
            this.Bill.Text = "Bill";
            this.Bill.UseVisualStyleBackColor = false;
            this.Bill.Click += new System.EventHandler(this.Bill_Click);
            // 
            // Kitchen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::FristApp.Properties.Resources.chefs_in_kitchen;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.Controls.Add(this.Bill);
            this.Controls.Add(this.comboW);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.Kit);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textSum);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.OrdermassageLbl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Kitchen";
            this.Text = "kitchen";
            this.Load += new System.EventHandler(this.Kitchen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Kit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label OrdermassageLbl;
        public System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textSum;
        private System.Windows.Forms.Button button1;
        public System.Windows.Forms.DataGridView Kit;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboW;
        private System.Windows.Forms.Button Bill;
    }
}