﻿using System;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace FristApp
{
    public partial class AddFood : Form
    {
        string imgLoc = "";
        private  SqlCommand myCommand;
        private SqlConnection con=new SqlConnection();
        //SqlDataReader dr;
        
        public AddFood()
        {
            InitializeComponent();
        }

        private void Browse_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog();
                dlg.Filter = "JPG Files(*.jpg)|*.jpg|GIF Files (*.gif)|*.gif|All Files (*.*)|*.*";
                dlg.Title = "Select Food Picture";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    imgLoc = dlg.FileName.ToString();
                    pictureBox1.ImageLocation = imgLoc;

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error");
            }
        }

        private void Add_Food(object sender, EventArgs e)
        {
            int s1 = Convert.ToInt32(this.textId.Text);
            string s2 = this.textName.Text;
            int s3 = Convert.ToInt32(this.textprice.Text);
            string s4 = this.TypeCombo.Text;
            byte[] img = null;
            FileStream stream = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
            BinaryReader reader = new BinaryReader(stream);
            img = reader.ReadBytes((int)stream.Length);
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");
                string query = "INSERT into Food (Id,Name,Price,Type,Image) VALUES ('" + s1 + "', '" + s2 + "', '" + s3 + "', '" + s4 + "',@img)";
                con.Open();
                myCommand = new SqlCommand(query,con);
                myCommand.Parameters.Add(new SqlParameter("@img", img));
                int x = myCommand.ExecuteNonQuery();

                    MessageBox.Show("Registered");
                con.Close();
                
            }
            catch (Exception r)
            {
                MessageBox.Show("Problem");
            }
        }

        private void BAck_Emp(object sender, EventArgs e)
        {
            this.Close();
            AddEmployee e1 = new AddEmployee();
            e1.Show();
        }
    }
}
