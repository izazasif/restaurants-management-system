﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FristApp
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void FormC(object sender, EventArgs e)
        {
            if (radio1.Checked == true)
            {
                Guest f1 = new Guest();
                f1.Show();
            }
            if (radio2.Checked == true)
            {
                KitchenLogin kl = new KitchenLogin();
                kl.Show();
            }
            if (radio3.Checked == true)
            {
                ManagmentLogin m1 = new ManagmentLogin();
                m1.Show();
            }
            this.Hide();
        }
        private void LoginButtonHovered(object sender, EventArgs e)
        {
            Enter.BackColor = Color.Blue;
            Enter.ForeColor = Color.White;
        }

        private void LoginBtnLeft(object sender, EventArgs e)
        {
            Enter.BackColor = Color.Gray;
            Enter.ForeColor = Color.Green;
        }
        
    }
}
