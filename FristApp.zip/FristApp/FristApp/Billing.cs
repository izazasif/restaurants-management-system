﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using itextsharp.pdfa;
using iTextSharp.text;
using System.IO;
using iTextSharp.text.pdf;
using System.Data.SqlClient;

namespace FristApp
{
    public partial class Billing : Form
    {
        public Billing()
        {
            InitializeComponent();
           
        }
       
        private void BAck(object sender, EventArgs e)
        {
            this.Close();
            AddEmployee nw = new AddEmployee();
            nw.Show();
        }


        private void Search_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");
            string query = "Select * from Bill where TableNo="+int.Parse(textBox4.Text);
          
            con.Open();
            SqlCommand mycommand = new SqlCommand(query, con);
            SqlDataReader s = mycommand.ExecuteReader();
            if(s.Read())
            {
                textBox1.Text = (s["Name"].ToString());
                textBox2.Text = (s["Total"].ToString());
                textBox3.Text = (s["WaiterName"].ToString());


            }
            con.Close();
        }
        private void Create_Bill(object sender, EventArgs e)

        {
            string s1 = textBox4.Text;
            string s2 = textBox1.Text;
            string s3 = textBox2.Text;
            string s4 = textBox3.Text;
            Document doc = new Document(iTextSharp.text.PageSize.LETTER, 10, 10, 42, 35);
            PdfWriter wri = PdfWriter.GetInstance(doc, new FileStream("Bill.pdf", FileMode.Create));
            doc.Open();
            Paragraph par = new Paragraph(s1);
            Paragraph par1 = new Paragraph(s2);
            Paragraph par2= new Paragraph(s3);
            Paragraph par3 = new Paragraph(s4);
            doc.Add(par);
            doc.Add(par1);
            doc.Add(par2);
            doc.Add(par3);
            doc.Close();
        }
    }
}
