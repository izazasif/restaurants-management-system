﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using RestaurentRepository;

namespace FristApp
{
    public partial class CardPayment : Form
    {
        public CardPayment()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "INSERT into cardpayment (cardnumber,billamount,bankname) VALUES ('" + cardnumbertextBox.Text + "','" + billamounttextBox.Text + "','" + bankcomboBox.Text +")";
                CoonectionClass dcc = new CoonectionClass();
                dcc.ConnectWithDB();
                int x = dcc.ExecuteSQL(query);
                MessageBox.Show("compleate payment");
                dcc.CloseConnection();

            }
            catch (Exception r)
            {
                MessageBox.Show("Problem");
            }

        }
    }
}
