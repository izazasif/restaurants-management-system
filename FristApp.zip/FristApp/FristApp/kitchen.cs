﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RestaurentRepository;
using System.Data.SqlClient;

namespace FristApp
{
    public partial class Kitchen : Form

    {
        

        public Kitchen()
        {
            InitializeComponent();
            fillCombo();
        }

        void fillCombo()
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Documents\Registration.mdf;Integrated Security=True;Connect Timeout=30");
            string query = "Select * from Employeinfo where eposition=@Waiter";
            //con.Open();
            SqlCommand mycommand = new SqlCommand(query, con);
            mycommand.Parameters.AddWithValue("@Waiter", "Waiter");
            SqlDataReader Reader;
            try
            {
                con.Open();
                Reader = mycommand.ExecuteReader();

                while (Reader.Read())
                {

                    String sname = (string)Reader["ename"];
                    comboW.Items.Add(sname);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("not Update");
            }
            }

        private void Kitchen_Load(object sender, EventArgs e)
        {
            textBox1.Text = Guest.passingText1;
            textBox2.Text = Guest.passingText2;
            
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sum = 0;
            for (int i = 0; i < Kit.Rows.Count; i++)
            {
                sum += Convert.ToInt32(Kit.Rows[i].Cells[1].Value);
            }
            //  MessageBox.Show(sum.ToString());
            this.textSum.Text = sum.ToString();
        }

        private void Bill_Click(object sender, EventArgs e)
        {
              
            int s1 = Convert.ToInt32(textBox2.Text);
            string s2 = textBox1.Text;
            int s3 = Convert.ToInt32(textSum.Text);
            string s4 = comboW.Text;
            
            string query = "INSERT INTO Bill (TableNo,Name,Total,WaiterName) VALUES ('" + s1 + "','" +s2 + "','" + s3 + "','" + s4+ "')";
            CoonectionClass dcc = new CoonectionClass();
            dcc.ConnectWithDB();
            int x = dcc.ExecuteSQL(query);
            dcc.CloseConnection();
            MessageBox.Show("Complate");
        }

        private void Kit_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
