﻿namespace FristApp
{
    partial class Guest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Guest));
            this.tab0 = new System.Windows.Forms.TabControl();
            this.tab = new System.Windows.Forms.TabPage();
            this.Addbutton4 = new System.Windows.Forms.Button();
            this.texttype4 = new System.Windows.Forms.TextBox();
            this.textprice4 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.view5 = new System.Windows.Forms.Button();
            this.comboperson4 = new System.Windows.Forms.ComboBox();
            this.combobangla = new System.Windows.Forms.ComboBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.view = new System.Windows.Forms.Button();
            this.tab3 = new System.Windows.Forms.TabPage();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.Add_Chart = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textP = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textB = new System.Windows.Forms.TextBox();
            this.picture = new System.Windows.Forms.PictureBox();
            this.comboCh = new System.Windows.Forms.ComboBox();
            this.view2 = new System.Windows.Forms.Button();
            this.tab4 = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.texttype = new System.Windows.Forms.TextBox();
            this.textprice = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.picture1 = new System.Windows.Forms.PictureBox();
            this.Addbutton = new System.Windows.Forms.Button();
            this.view1 = new System.Windows.Forms.Button();
            this.comboperson = new System.Windows.Forms.ComboBox();
            this.combothai = new System.Windows.Forms.ComboBox();
            this.tab5 = new System.Windows.Forms.TabPage();
            this.texttype2 = new System.Windows.Forms.TextBox();
            this.textprice2 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Addbutton2 = new System.Windows.Forms.Button();
            this.view3 = new System.Windows.Forms.Button();
            this.comboperson2 = new System.Windows.Forms.ComboBox();
            this.comboindian = new System.Windows.Forms.ComboBox();
            this.tab1 = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Addbutton3 = new System.Windows.Forms.Button();
            this.texttype3 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textprice3 = new System.Windows.Forms.TextBox();
            this.view4 = new System.Windows.Forms.Button();
            this.comboperson3 = new System.Windows.Forms.ComboBox();
            this.combodeseart = new System.Windows.Forms.ComboBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.pictureBoxBeverage = new System.Windows.Forms.PictureBox();
            this.AddbuttonBeverage = new System.Windows.Forms.Button();
            this.TypetextBoxBeverage = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.pricetextBoxBeverage = new System.Windows.Forms.TextBox();
            this.ViewbtnBeverage = new System.Windows.Forms.Button();
            this.comboBoxBeverage = new System.Windows.Forms.ComboBox();
            this.comboBeverage = new System.Windows.Forms.ComboBox();
            this.BackButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.con_button = new System.Windows.Forms.Button();
            this.comboTab = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.tab0.SuspendLayout();
            this.tab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.tab3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture)).BeginInit();
            this.tab4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture1)).BeginInit();
            this.tab5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tab1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBeverage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tab0
            // 
            this.tab0.Controls.Add(this.tab);
            this.tab0.Controls.Add(this.tab3);
            this.tab0.Controls.Add(this.tab4);
            this.tab0.Controls.Add(this.tab5);
            this.tab0.Controls.Add(this.tab1);
            this.tab0.Controls.Add(this.tabPage1);
            this.tab0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tab0.Location = new System.Drawing.Point(0, 25);
            this.tab0.Name = "tab0";
            this.tab0.SelectedIndex = 0;
            this.tab0.Size = new System.Drawing.Size(507, 481);
            this.tab0.TabIndex = 0;
            // 
            // tab
            // 
            this.tab.BackColor = System.Drawing.Color.Maroon;
            this.tab.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tab.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tab.Controls.Add(this.Addbutton4);
            this.tab.Controls.Add(this.texttype4);
            this.tab.Controls.Add(this.textprice4);
            this.tab.Controls.Add(this.label11);
            this.tab.Controls.Add(this.label10);
            this.tab.Controls.Add(this.pictureBox5);
            this.tab.Controls.Add(this.view5);
            this.tab.Controls.Add(this.comboperson4);
            this.tab.Controls.Add(this.combobangla);
            this.tab.Controls.Add(this.pictureBox4);
            this.tab.Controls.Add(this.pictureBox3);
            this.tab.Controls.Add(this.view);
            this.tab.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.tab.Location = new System.Drawing.Point(4, 25);
            this.tab.Name = "tab";
            this.tab.Padding = new System.Windows.Forms.Padding(3);
            this.tab.Size = new System.Drawing.Size(499, 452);
            this.tab.TabIndex = 0;
            this.tab.Text = "Bangla";
            this.tab.Click += new System.EventHandler(this.tab_Click);
            // 
            // Addbutton4
            // 
            this.Addbutton4.Location = new System.Drawing.Point(285, 390);
            this.Addbutton4.Name = "Addbutton4";
            this.Addbutton4.Size = new System.Drawing.Size(133, 35);
            this.Addbutton4.TabIndex = 21;
            this.Addbutton4.Text = "Add Item";
            this.Addbutton4.UseVisualStyleBackColor = true;
            this.Addbutton4.Click += new System.EventHandler(this.AddBangla);
            // 
            // texttype4
            // 
            this.texttype4.Location = new System.Drawing.Point(285, 339);
            this.texttype4.Name = "texttype4";
            this.texttype4.Size = new System.Drawing.Size(133, 22);
            this.texttype4.TabIndex = 20;
            // 
            // textprice4
            // 
            this.textprice4.Location = new System.Drawing.Point(285, 290);
            this.textprice4.Name = "textprice4";
            this.textprice4.Size = new System.Drawing.Size(133, 22);
            this.textprice4.TabIndex = 19;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(190, 339);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 16);
            this.label11.TabIndex = 18;
            this.label11.Text = "Type";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(190, 292);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 16);
            this.label10.TabIndex = 17;
            this.label10.Text = "Price";
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.RosyBrown;
            this.pictureBox5.Location = new System.Drawing.Point(231, 32);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(204, 213);
            this.pictureBox5.TabIndex = 16;
            this.pictureBox5.TabStop = false;
            // 
            // view5
            // 
            this.view5.Location = new System.Drawing.Point(26, 307);
            this.view5.Name = "view5";
            this.view5.Size = new System.Drawing.Size(133, 35);
            this.view5.TabIndex = 15;
            this.view5.Text = "View";
            this.view5.UseVisualStyleBackColor = true;
            this.view5.Click += new System.EventHandler(this.view6click);
            // 
            // comboperson4
            // 
            this.comboperson4.FormattingEnabled = true;
            this.comboperson4.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboperson4.Location = new System.Drawing.Point(26, 103);
            this.comboperson4.Name = "comboperson4";
            this.comboperson4.Size = new System.Drawing.Size(128, 24);
            this.comboperson4.TabIndex = 14;
            this.comboperson4.Text = "Select Person";
            // 
            // combobangla
            // 
            this.combobangla.FormattingEnabled = true;
            this.combobangla.Location = new System.Drawing.Point(26, 59);
            this.combobangla.Name = "combobangla";
            this.combobangla.Size = new System.Drawing.Size(128, 24);
            this.combobangla.TabIndex = 13;
            this.combobangla.Text = "Item type";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Location = new System.Drawing.Point(776, 13);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(157, 114);
            this.pictureBox4.TabIndex = 12;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(578, 13);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(165, 114);
            this.pictureBox3.TabIndex = 11;
            this.pictureBox3.TabStop = false;
            // 
            // view
            // 
            this.view.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.view.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.view.ForeColor = System.Drawing.SystemColors.InfoText;
            this.view.Location = new System.Drawing.Point(872, 390);
            this.view.Name = "view";
            this.view.Size = new System.Drawing.Size(61, 33);
            this.view.TabIndex = 2;
            this.view.Text = "View\r\n";
            this.view.UseVisualStyleBackColor = true;
            this.view.Click += new System.EventHandler(this.tab_Click);
            // 
            // tab3
            // 
            this.tab3.BackColor = System.Drawing.Color.Sienna;
            this.tab3.Controls.Add(this.comboBox2);
            this.tab3.Controls.Add(this.Add_Chart);
            this.tab3.Controls.Add(this.label3);
            this.tab3.Controls.Add(this.label2);
            this.tab3.Controls.Add(this.textP);
            this.tab3.Controls.Add(this.label1);
            this.tab3.Controls.Add(this.textB);
            this.tab3.Controls.Add(this.picture);
            this.tab3.Controls.Add(this.comboCh);
            this.tab3.Controls.Add(this.view2);
            this.tab3.Location = new System.Drawing.Point(4, 25);
            this.tab3.Name = "tab3";
            this.tab3.Size = new System.Drawing.Size(499, 452);
            this.tab3.TabIndex = 2;
            this.tab3.Text = "Chinese";
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBox2.Location = new System.Drawing.Point(8, 123);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 28);
            this.comboBox2.TabIndex = 10;
            this.comboBox2.Text = "Select Person";
            // 
            // Add_Chart
            // 
            this.Add_Chart.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add_Chart.Location = new System.Drawing.Point(217, 323);
            this.Add_Chart.Name = "Add_Chart";
            this.Add_Chart.Size = new System.Drawing.Size(149, 46);
            this.Add_Chart.TabIndex = 9;
            this.Add_Chart.Text = "Add Iteam";
            this.Add_Chart.UseVisualStyleBackColor = true;
            this.Add_Chart.Click += new System.EventHandler(this.AddClick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(178, 249);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 24);
            this.label3.TabIndex = 8;
            this.label3.Text = "Type";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(167, 211);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 25);
            this.label2.TabIndex = 7;
            this.label2.Text = "Price";
            this.label2.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // textP
            // 
            this.textP.Location = new System.Drawing.Point(237, 249);
            this.textP.Multiline = true;
            this.textP.Name = "textP";
            this.textP.Size = new System.Drawing.Size(100, 54);
            this.textP.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Niagara Solid", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Location = new System.Drawing.Point(231, 199);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 19);
            this.label1.TabIndex = 5;
            // 
            // textB
            // 
            this.textB.Location = new System.Drawing.Point(237, 201);
            this.textB.Multiline = true;
            this.textB.Name = "textB";
            this.textB.Size = new System.Drawing.Size(156, 42);
            this.textB.TabIndex = 4;
            // 
            // picture
            // 
            this.picture.BackColor = System.Drawing.Color.MistyRose;
            this.picture.Location = new System.Drawing.Point(183, 13);
            this.picture.Name = "picture";
            this.picture.Size = new System.Drawing.Size(209, 173);
            this.picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picture.TabIndex = 3;
            this.picture.TabStop = false;
            // 
            // comboCh
            // 
            this.comboCh.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboCh.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboCh.FormattingEnabled = true;
            this.comboCh.IntegralHeight = false;
            this.comboCh.Location = new System.Drawing.Point(8, 89);
            this.comboCh.Name = "comboCh";
            this.comboCh.Size = new System.Drawing.Size(112, 28);
            this.comboCh.TabIndex = 1;
            this.comboCh.Text = "Iteam";
            this.comboCh.SelectedIndexChanged += new System.EventHandler(this.comboCh_SelectedIndexChanged);
            // 
            // view2
            // 
            this.view2.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.view2.Location = new System.Drawing.Point(38, 280);
            this.view2.Name = "view2";
            this.view2.Size = new System.Drawing.Size(102, 23);
            this.view2.TabIndex = 0;
            this.view2.Text = "View";
            this.view2.UseVisualStyleBackColor = true;
            this.view2.Click += new System.EventHandler(this.View2_Click);
            // 
            // tab4
            // 
            this.tab4.BackColor = System.Drawing.Color.DarkRed;
            this.tab4.Controls.Add(this.label7);
            this.tab4.Controls.Add(this.texttype);
            this.tab4.Controls.Add(this.textprice);
            this.tab4.Controls.Add(this.label4);
            this.tab4.Controls.Add(this.picture1);
            this.tab4.Controls.Add(this.Addbutton);
            this.tab4.Controls.Add(this.view1);
            this.tab4.Controls.Add(this.comboperson);
            this.tab4.Controls.Add(this.combothai);
            this.tab4.ForeColor = System.Drawing.Color.Black;
            this.tab4.Location = new System.Drawing.Point(4, 25);
            this.tab4.Name = "tab4";
            this.tab4.Size = new System.Drawing.Size(499, 452);
            this.tab4.TabIndex = 3;
            this.tab4.Text = "Thai";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(208, 278);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 16);
            this.label7.TabIndex = 9;
            this.label7.Text = "Type";
            // 
            // texttype
            // 
            this.texttype.Location = new System.Drawing.Point(279, 273);
            this.texttype.Name = "texttype";
            this.texttype.Size = new System.Drawing.Size(146, 22);
            this.texttype.TabIndex = 8;
            // 
            // textprice
            // 
            this.textprice.Location = new System.Drawing.Point(279, 233);
            this.textprice.Name = "textprice";
            this.textprice.Size = new System.Drawing.Size(146, 22);
            this.textprice.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(210, 239);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "Price";
            // 
            // picture1
            // 
            this.picture1.BackColor = System.Drawing.Color.LightCoral;
            this.picture1.Location = new System.Drawing.Point(225, 21);
            this.picture1.Name = "picture1";
            this.picture1.Size = new System.Drawing.Size(218, 184);
            this.picture1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picture1.TabIndex = 4;
            this.picture1.TabStop = false;
            // 
            // Addbutton
            // 
            this.Addbutton.Location = new System.Drawing.Point(279, 323);
            this.Addbutton.Name = "Addbutton";
            this.Addbutton.Size = new System.Drawing.Size(121, 40);
            this.Addbutton.TabIndex = 3;
            this.Addbutton.Text = "Add Item";
            this.Addbutton.UseVisualStyleBackColor = true;
            this.Addbutton.Click += new System.EventHandler(this.button3_Click);
            // 
            // view1
            // 
            this.view1.Location = new System.Drawing.Point(44, 266);
            this.view1.Name = "view1";
            this.view1.Size = new System.Drawing.Size(121, 40);
            this.view1.TabIndex = 2;
            this.view1.Text = "View";
            this.view1.UseVisualStyleBackColor = true;
            this.view1.Click += new System.EventHandler(this.view3click);
            // 
            // comboperson
            // 
            this.comboperson.FormattingEnabled = true;
            this.comboperson.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboperson.Location = new System.Drawing.Point(32, 110);
            this.comboperson.Name = "comboperson";
            this.comboperson.Size = new System.Drawing.Size(121, 24);
            this.comboperson.TabIndex = 1;
            this.comboperson.Text = "Select Person";
            // 
            // combothai
            // 
            this.combothai.Font = new System.Drawing.Font("Wide Latin", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combothai.FormattingEnabled = true;
            this.combothai.Location = new System.Drawing.Point(32, 63);
            this.combothai.Name = "combothai";
            this.combothai.Size = new System.Drawing.Size(121, 31);
            this.combothai.TabIndex = 0;
            this.combothai.Text = "Item";
            this.combothai.SelectedIndexChanged += new System.EventHandler(this.combothai_SelectedIndexChanged);
            // 
            // tab5
            // 
            this.tab5.BackColor = System.Drawing.Color.OrangeRed;
            this.tab5.Controls.Add(this.texttype2);
            this.tab5.Controls.Add(this.textprice2);
            this.tab5.Controls.Add(this.label9);
            this.tab5.Controls.Add(this.label8);
            this.tab5.Controls.Add(this.pictureBox2);
            this.tab5.Controls.Add(this.Addbutton2);
            this.tab5.Controls.Add(this.view3);
            this.tab5.Controls.Add(this.comboperson2);
            this.tab5.Controls.Add(this.comboindian);
            this.tab5.Location = new System.Drawing.Point(4, 25);
            this.tab5.Name = "tab5";
            this.tab5.Size = new System.Drawing.Size(499, 452);
            this.tab5.TabIndex = 4;
            this.tab5.Text = "Indian";
            // 
            // texttype2
            // 
            this.texttype2.Location = new System.Drawing.Point(285, 325);
            this.texttype2.Name = "texttype2";
            this.texttype2.Size = new System.Drawing.Size(127, 22);
            this.texttype2.TabIndex = 8;
            // 
            // textprice2
            // 
            this.textprice2.Location = new System.Drawing.Point(285, 275);
            this.textprice2.Name = "textprice2";
            this.textprice2.Size = new System.Drawing.Size(127, 22);
            this.textprice2.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(208, 325);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 16);
            this.label9.TabIndex = 6;
            this.label9.Text = "Type";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(208, 279);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 16);
            this.label8.TabIndex = 5;
            this.label8.Text = "Price";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.MistyRose;
            this.pictureBox2.Location = new System.Drawing.Point(234, 19);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(220, 232);
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // Addbutton2
            // 
            this.Addbutton2.Location = new System.Drawing.Point(249, 381);
            this.Addbutton2.Name = "Addbutton2";
            this.Addbutton2.Size = new System.Drawing.Size(137, 40);
            this.Addbutton2.TabIndex = 3;
            this.Addbutton2.Text = "Add Item";
            this.Addbutton2.UseVisualStyleBackColor = true;
            this.Addbutton2.Click += new System.EventHandler(this.AddIndian);
            // 
            // view3
            // 
            this.view3.Location = new System.Drawing.Point(47, 301);
            this.view3.Name = "view3";
            this.view3.Size = new System.Drawing.Size(137, 40);
            this.view3.TabIndex = 2;
            this.view3.Text = "View";
            this.view3.UseVisualStyleBackColor = true;
            this.view3.Click += new System.EventHandler(this.view4Click);
            // 
            // comboperson2
            // 
            this.comboperson2.FormattingEnabled = true;
            this.comboperson2.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboperson2.Location = new System.Drawing.Point(28, 142);
            this.comboperson2.Name = "comboperson2";
            this.comboperson2.Size = new System.Drawing.Size(144, 24);
            this.comboperson2.TabIndex = 1;
            this.comboperson2.Text = "Select Person";
            // 
            // comboindian
            // 
            this.comboindian.Font = new System.Drawing.Font("Modern No. 20", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboindian.FormattingEnabled = true;
            this.comboindian.Location = new System.Drawing.Point(28, 81);
            this.comboindian.Name = "comboindian";
            this.comboindian.Size = new System.Drawing.Size(144, 42);
            this.comboindian.TabIndex = 0;
            this.comboindian.Text = "  Item";
            // 
            // tab1
            // 
            this.tab1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.tab1.Controls.Add(this.pictureBox1);
            this.tab1.Controls.Add(this.Addbutton3);
            this.tab1.Controls.Add(this.texttype3);
            this.tab1.Controls.Add(this.label6);
            this.tab1.Controls.Add(this.label5);
            this.tab1.Controls.Add(this.textprice3);
            this.tab1.Controls.Add(this.view4);
            this.tab1.Controls.Add(this.comboperson3);
            this.tab1.Controls.Add(this.combodeseart);
            this.tab1.Location = new System.Drawing.Point(4, 25);
            this.tab1.Name = "tab1";
            this.tab1.Padding = new System.Windows.Forms.Padding(3);
            this.tab1.Size = new System.Drawing.Size(499, 452);
            this.tab1.TabIndex = 1;
            this.tab1.Text = "Desart";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.MintCream;
            this.pictureBox1.Location = new System.Drawing.Point(239, 36);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(202, 214);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // Addbutton3
            // 
            this.Addbutton3.Location = new System.Drawing.Point(304, 390);
            this.Addbutton3.Name = "Addbutton3";
            this.Addbutton3.Size = new System.Drawing.Size(100, 32);
            this.Addbutton3.TabIndex = 7;
            this.Addbutton3.Text = "Add Item";
            this.Addbutton3.UseVisualStyleBackColor = true;
            this.Addbutton3.Click += new System.EventHandler(this.AddDeseart);
            // 
            // texttype3
            // 
            this.texttype3.Location = new System.Drawing.Point(292, 344);
            this.texttype3.Name = "texttype3";
            this.texttype3.Size = new System.Drawing.Size(126, 22);
            this.texttype3.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(192, 344);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Type";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(192, 281);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Price";
            // 
            // textprice3
            // 
            this.textprice3.Location = new System.Drawing.Point(292, 277);
            this.textprice3.Name = "textprice3";
            this.textprice3.Size = new System.Drawing.Size(126, 22);
            this.textprice3.TabIndex = 3;
            // 
            // view4
            // 
            this.view4.Location = new System.Drawing.Point(26, 300);
            this.view4.Name = "view4";
            this.view4.Size = new System.Drawing.Size(128, 44);
            this.view4.TabIndex = 2;
            this.view4.Text = "View";
            this.view4.UseVisualStyleBackColor = true;
            this.view4.Click += new System.EventHandler(this.view5click);
            // 
            // comboperson3
            // 
            this.comboperson3.FormattingEnabled = true;
            this.comboperson3.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboperson3.Location = new System.Drawing.Point(26, 127);
            this.comboperson3.Name = "comboperson3";
            this.comboperson3.Size = new System.Drawing.Size(128, 24);
            this.comboperson3.TabIndex = 1;
            this.comboperson3.Text = "Select Person";
            // 
            // combodeseart
            // 
            this.combodeseart.Font = new System.Drawing.Font("Modern No. 20", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combodeseart.FormattingEnabled = true;
            this.combodeseart.Location = new System.Drawing.Point(26, 63);
            this.combodeseart.Name = "combodeseart";
            this.combodeseart.Size = new System.Drawing.Size(128, 42);
            this.combodeseart.TabIndex = 0;
            this.combodeseart.Text = "Item";
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.tabPage1.Controls.Add(this.pictureBoxBeverage);
            this.tabPage1.Controls.Add(this.AddbuttonBeverage);
            this.tabPage1.Controls.Add(this.TypetextBoxBeverage);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.pricetextBoxBeverage);
            this.tabPage1.Controls.Add(this.ViewbtnBeverage);
            this.tabPage1.Controls.Add(this.comboBoxBeverage);
            this.tabPage1.Controls.Add(this.comboBeverage);
            this.tabPage1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(499, 452);
            this.tabPage1.TabIndex = 5;
            this.tabPage1.Text = "Beverage";
            // 
            // pictureBoxBeverage
            // 
            this.pictureBoxBeverage.BackColor = System.Drawing.Color.MintCream;
            this.pictureBoxBeverage.Location = new System.Drawing.Point(255, 33);
            this.pictureBoxBeverage.Name = "pictureBoxBeverage";
            this.pictureBoxBeverage.Size = new System.Drawing.Size(202, 214);
            this.pictureBoxBeverage.TabIndex = 17;
            this.pictureBoxBeverage.TabStop = false;
            // 
            // AddbuttonBeverage
            // 
            this.AddbuttonBeverage.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.AddbuttonBeverage.Location = new System.Drawing.Point(320, 387);
            this.AddbuttonBeverage.Name = "AddbuttonBeverage";
            this.AddbuttonBeverage.Size = new System.Drawing.Size(100, 32);
            this.AddbuttonBeverage.TabIndex = 16;
            this.AddbuttonBeverage.Text = "Add Item";
            this.AddbuttonBeverage.UseVisualStyleBackColor = true;
            this.AddbuttonBeverage.Click += new System.EventHandler(this.AddbuttonBeverage_Click);
            // 
            // TypetextBoxBeverage
            // 
            this.TypetextBoxBeverage.Location = new System.Drawing.Point(308, 341);
            this.TypetextBoxBeverage.Name = "TypetextBoxBeverage";
            this.TypetextBoxBeverage.Size = new System.Drawing.Size(126, 22);
            this.TypetextBoxBeverage.TabIndex = 15;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(208, 341);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(44, 16);
            this.label12.TabIndex = 14;
            this.label12.Text = "Type";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(208, 278);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 16);
            this.label13.TabIndex = 13;
            this.label13.Text = "Price";
            // 
            // pricetextBoxBeverage
            // 
            this.pricetextBoxBeverage.Location = new System.Drawing.Point(308, 274);
            this.pricetextBoxBeverage.Name = "pricetextBoxBeverage";
            this.pricetextBoxBeverage.Size = new System.Drawing.Size(126, 22);
            this.pricetextBoxBeverage.TabIndex = 12;
            // 
            // ViewbtnBeverage
            // 
            this.ViewbtnBeverage.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ViewbtnBeverage.Location = new System.Drawing.Point(42, 299);
            this.ViewbtnBeverage.Name = "ViewbtnBeverage";
            this.ViewbtnBeverage.Size = new System.Drawing.Size(128, 44);
            this.ViewbtnBeverage.TabIndex = 11;
            this.ViewbtnBeverage.Text = "View";
            this.ViewbtnBeverage.UseVisualStyleBackColor = true;
            this.ViewbtnBeverage.Click += new System.EventHandler(this.ViewbtnBeverage_Click);
            // 
            // comboBoxBeverage
            // 
            this.comboBoxBeverage.FormattingEnabled = true;
            this.comboBoxBeverage.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.comboBoxBeverage.Location = new System.Drawing.Point(42, 124);
            this.comboBoxBeverage.Name = "comboBoxBeverage";
            this.comboBoxBeverage.Size = new System.Drawing.Size(128, 24);
            this.comboBoxBeverage.TabIndex = 10;
            this.comboBoxBeverage.Text = "Select Person";
            // 
            // comboBeverage1
            // 
            this.comboBeverage.Font = new System.Drawing.Font("Modern No. 20", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBeverage.FormattingEnabled = true;
            this.comboBeverage.Location = new System.Drawing.Point(42, 60);
            this.comboBeverage.Name = "comboBeverage1";
            this.comboBeverage.Size = new System.Drawing.Size(128, 42);
            this.comboBeverage.TabIndex = 9;
            this.comboBeverage.Text = "Item";
            // 
            // BackButton
            // 
            this.BackButton.BackColor = System.Drawing.Color.Maroon;
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton.Location = new System.Drawing.Point(509, 0);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(114, 27);
            this.BackButton.TabIndex = 0;
            this.BackButton.Text = "Back Home";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.Home);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(509, 46);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(468, 331);
            this.dataGridView1.TabIndex = 2;
            // 
            // con_button
            // 
            this.con_button.BackColor = System.Drawing.Color.MistyRose;
            this.con_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.con_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.con_button.Location = new System.Drawing.Point(596, 440);
            this.con_button.Name = "con_button";
            this.con_button.Size = new System.Drawing.Size(125, 35);
            this.con_button.TabIndex = 3;
            this.con_button.Text = "Confirm";
            this.con_button.UseVisualStyleBackColor = false;
            this.con_button.Click += new System.EventHandler(this.con_click);
            // 
            // comboTab
            // 
            this.comboTab.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboTab.FormattingEnabled = true;
            this.comboTab.Items.AddRange(new object[] {
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.comboTab.Location = new System.Drawing.Point(513, 391);
            this.comboTab.Name = "comboTab";
            this.comboTab.Size = new System.Drawing.Size(121, 26);
            this.comboTab.TabIndex = 6;
            this.comboTab.Text = "Select Table";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Maroon;
            this.label14.Location = new System.Drawing.Point(752, 397);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(49, 16);
            this.label14.TabIndex = 8;
            this.label14.Text = "Name";
            // 
            // name
            // 
            this.name.Location = new System.Drawing.Point(646, 393);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(93, 20);
            this.name.TabIndex = 7;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(811, 449);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(138, 28);
            this.button1.TabIndex = 9;
            this.button1.Text = "Delete Iteam";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Del_Ite);
            // 
            // Guest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.name);
            this.Controls.Add(this.comboTab);
            this.Controls.Add(this.con_button);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.tab0);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Guest";
            this.Text = "OrderForm";
            this.tab0.ResumeLayout(false);
            this.tab.ResumeLayout(false);
            this.tab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.tab3.ResumeLayout(false);
            this.tab3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture)).EndInit();
            this.tab4.ResumeLayout(false);
            this.tab4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picture1)).EndInit();
            this.tab5.ResumeLayout(false);
            this.tab5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tab1.ResumeLayout(false);
            this.tab1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBeverage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tab0;
        private System.Windows.Forms.TabPage tab1;
        private System.Windows.Forms.TabPage tab3;
        private System.Windows.Forms.TabPage tab4;
        private System.Windows.Forms.TabPage tab5;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.TabPage tab;
        private System.Windows.Forms.Button view;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button view2;
        private System.Windows.Forms.PictureBox picture;
        private System.Windows.Forms.ComboBox comboCh;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textP;
        private System.Windows.Forms.Button Add_Chart;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.TextBox texttype;
        private System.Windows.Forms.TextBox textprice;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox picture1;
        private System.Windows.Forms.Button Addbutton;
        private System.Windows.Forms.Button view1;
        private System.Windows.Forms.ComboBox comboperson;
        private System.Windows.Forms.ComboBox combothai;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button con_button;
        private System.Windows.Forms.TextBox texttype2;
        private System.Windows.Forms.TextBox textprice2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button Addbutton2;
        private System.Windows.Forms.Button view3;
        private System.Windows.Forms.ComboBox comboperson2;
        private System.Windows.Forms.ComboBox comboindian;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Addbutton3;
        private System.Windows.Forms.TextBox texttype3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textprice3;
        private System.Windows.Forms.Button view4;
        private System.Windows.Forms.ComboBox comboperson3;
        private System.Windows.Forms.ComboBox combodeseart;
        private System.Windows.Forms.Button Addbutton4;
        private System.Windows.Forms.TextBox texttype4;
        private System.Windows.Forms.TextBox textprice4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button view5;
        private System.Windows.Forms.ComboBox comboperson4;
        private System.Windows.Forms.ComboBox combobangla;
        private System.Windows.Forms.PictureBox pictureBoxBeverage;
        private System.Windows.Forms.Button AddbuttonBeverage;
        private System.Windows.Forms.TextBox TypetextBoxBeverage;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox pricetextBoxBeverage;
        private System.Windows.Forms.Button ViewbtnBeverage;
        private System.Windows.Forms.ComboBox comboBoxBeverage;
        private System.Windows.Forms.ComboBox comboBeverage;
        private System.Windows.Forms.ComboBox comboTab;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.Button button1;
    }
}