﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using RestaurentRepository;

namespace FristApp
{
    public partial class AddEmployee : Form
    {
        
        public AddEmployee()
        {
            InitializeComponent();
             
        }

        private void AddEmpBttn_Click(object sender, EventArgs e)
        {
            UpdateEmployeepanel.Hide();
            AddEmployeepanel.Show();

        }

        private void UpdateEmpBttn_Click(object sender, EventArgs e)
        {
            AddEmployeepanel.Hide();
            UpdateEmployeepanel.Show();
        }

        private void AddFoodbutton_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddFood f1 = new AddFood();
            f1.ShowDialog();
            this.Close();
        }


        private void Updatebutton_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "UPDATE Employeinfo SET Id='" + UPEIdtextBox.Text + "',ename='" + UPENametextBox.Text + "',epassword='" + UPEPasswordtextBox.Text + "', eposition='" + UPEPositioncomboBox.Text + "', emobilenumber='" + UPEPhonenumbertextBox.Text + " 'WHERE eusername='" + UPEUsernametextBox.Text + "'";
                CoonectionClass dcc = new CoonectionClass();
                dcc.ConnectWithDB();
                int x = dcc.ExecuteSQL(query);
                dcc.CloseConnection();
                MessageBox.Show("Employee Updated");
            }
            catch(Exception ex)
            {
                MessageBox.Show("NO update");
            }
            
        }

        private void Insertbutton_Click(object sender, EventArgs e)
        {
            
            string query = "INSERT INTO Employeinfo (Id,ename,eusername,epassword,emobilenumber,eposition) VALUES ('" + EIdtextBox.Text + "','" + ENametextBox.Text + "','" + EUsernametextBox.Text + "','" + EPasswordtextBox.Text + "','" + EPhoneNumbertextBox.Text + "','"+ EPositioncomboBox.Text+"')";
            CoonectionClass dcc = new CoonectionClass();
            dcc.ConnectWithDB();
            int x = dcc.ExecuteSQL(query);
            dcc.CloseConnection();
            MessageBox.Show("Employee Registered");
            
        }

        private void ExitBttn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home h = new Home();
            h.ShowDialog();
            this.Close();
        }

        private void SearchBttn_Click(object sender, EventArgs e)
        {
            this.Hide();
            EmployeeSearch s = new EmployeeSearch();
            s.ShowDialog();
            this.Close();
        }

        private void Bill_Click(object sender, EventArgs e)
        {
            Billing nw = new Billing();
            nw.Show();
            this.Close();
        }

        private void Delete_emp(object sender, EventArgs e)
        {

        }
    }
}
