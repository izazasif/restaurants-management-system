﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurentRepository
{
   public class Food
    {
        private string id;
        private string Name;
        private double Price;
        private string Type;
        public string ID
        {
            get { return id; }
            set { id = value; }
        }
        public string NAME
        {
            get { return Name; }
            set { Name = value; }
        }
        public double PRICE
        {
            get { return Price; }
            set { Price = value; }
        }
        public string TYPE
        {
            get { return Type; }
            set { Type = value; }
        }
    }
}
