﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurentRepository
{
    public class ConfirmCreate : IRest
    {
       
       public bool Insert(Bill a)
        {
            try
            {
                string query = "INSERT into Bill VALUES ('" + a.Table + "', " + a.NAME + "', '" + a.TOTAL + "', '" + a.WaiterNamE + "')";
                CoonectionClass dcc = new CoonectionClass();
                dcc.ConnectWithDB();
                int x = dcc.ExecuteSQL(query);
                dcc.CloseConnection();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
