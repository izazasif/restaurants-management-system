﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurentRepository
{
   public class Bill
    {
        private int TableNo;
        private string Name;
        private int Total ;
        private string WaiterName;
        public int Table
        {
            get { return TableNo; }
            set { TableNo = value; }
        }
        public string NAME
        {
            get { return Name; }
            set { Name = value; }
        }
        public int TOTAL
        {
            get { return Total; }
            set { Total = value; }
        }
        public string WaiterNamE
        {
            get { return WaiterName; }
            set { WaiterName = value; }
        }
    }
}
